<!doctype html>
<html>

    <head>
        <meta charset="utf-8">
        <title>Un fichier PHP tout simple !</title>

        <!-- Chargement de la police afin de ne plus être dans les années 90 -->
        <!--    Google web fonts > Bebas Neue > https://fonts.google.com/specimen/Bebas+Neue?query=bebas -->
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&display=swap" rel="stylesheet">

        <!-- Favicon -->
        <link rel="shortcut icon"     href="./assets/images/glorious-favicon.ico">
        <link rel="apple-touch-icon"  href="./assets/images/apple-touch-glorious-icon.png">

        <!-- Styles -->
        <link rel="stylesheet" href="./assets/css/normalize.css">
        <link rel="stylesheet" href="./assets/css/main.css">
    </head>

<body>
    <div>

        <h1>Un fichier PHP tout simple</h1>






        <p>

<?php
            // * Afficher du html dans du PHP
            // echo Pour afficher dans le html
            echo 'Bonjour tout le monde !'; echo 'Un autre bout de texte<br >';
            echo '<strong>Encore un</strong>';
            echo '<p>Un autre de plus !</p>';

            // Un syntaxe raccourcie d'affichage
            
            /* Ceci est un commentaire également */
            /* Ceci est un commentaire sur un morceaux de ligne */ echo 'hey';

            /*
            Commentaires
            sur
            plusieurs
            lignes
            */
?>

        </p>

        <hr>

        <!-- Afficher du PHP dans du HTML -->
        <p>
            <?= "Je suis affiché avec la syntaxe raccourcie !" ?>
            <?= "Un autre bout de texte<br >" ?>
        </p>
        <p><strong><?= "Encore un<br >" ?></strong></p>
        <p><?= 'Un autre de plus !'; ?></p>






    </div>
    
    <!-- Code en couleur -->
    <!-- @see / https://github.com/googlearchive/code-prettify -->
    <!-- Utiliser <pre class="prettyprint">le code</pre> -->
    <script src="https://cdn.jsdelivr.net/gh/google/code-prettify@master/loader/run_prettify.js?&amp;skin=sunburst"></script>
    
    <!-- Notre javascript -->
    <script src="./assets/js/main.js"></script>

</body>

</html>

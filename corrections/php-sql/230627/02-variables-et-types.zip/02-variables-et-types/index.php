<!doctype html>
<html>

    <head>
        <meta charset="utf-8">
        <title>Les variables et les types !</title>

        <!-- Chargement de la police afin de ne plus être dans les années 90 -->
        <!--    Google web fonts > Bebas Neue > https://fonts.google.com/specimen/Bebas+Neue?query=bebas -->
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&display=swap" rel="stylesheet">

        <!-- Favicon -->
        <link rel="shortcut icon"     href="./assets/images/glorious-favicon.ico">
        <link rel="apple-touch-icon"  href="./assets/images/apple-touch-glorious-icon.png">

        <!-- Styles -->
        <link rel="stylesheet" href="./assets/css/normalize.css">
        <link rel="stylesheet" href="./assets/css/main.css">
    </head>

<body>
    <div>

        <h1>Les variables et les types</h1>

<?php
    // * Comment on crée une variable en PHP ?
    $prenom = "Maxime";
    $nom = "Chev";
    // ^ Ce n'est pas affiché dans le html

    echo $prenom;
    echo $prenom;
    echo $prenom;
?>

<p>
    Mon prénom : <?= $prenom ?>
</p>

<?php
    // On peut également faire varier / changer / mettre à jour les variables
    $prenom = "Bob";
?>

<p>
    Mon nouveau prénom : <?= $prenom ?>
</p>

<hr>

<?php
    // * Types de variables
    //      Chaines de caractères
    $uneChaine = 'Avec des guillemets simples';
    $uneAutreChaine = "Avec des guillemets doubles";

    // ! Grosse différence entre les deux
    //      Dans les chaînes avec des guillets doubles, les variables sont interprétées

    $afficheCa = 'Une chaine avec mon prenom : $prenom';
?>
<p><?= $afficheCa ?></p>

<?php
    $afficheCaAussi = "Une chaine avec mon prenom : $prenom";
?>
<p><?= $afficheCaAussi ?></p>

<hr>

<?php
    // * Affichage des variables dans du texte ou du html
    //      Concatenation > caractère utilisé .
    $maPhrase = 'Mon prénom est ' . $prenom . ' et mon nom est ' . $nom . ' !';
?>
<p><?= $maPhrase ?></p>

<hr>

<?php
    // * Nombres
    $age = 15;
    
    // * Nombres à virgule
    //          comme leur nom l'indique, on utilise des points en séparateurs
    $pourcentage = 53.7;
    
    // * Booléens / vrai faux
    $jeSuisVrai = true;
    $jeSuisFaux = false;

    // * Tableaux
    //      Variable spéciale qui peut contenir plusieurs autres variables
    $prix = array(10, 20, 30);
?>

<hr>

<?php
    // ! Affichage Debug
    //      Une fonction dédiée principalement : var_dump()
    //      Afficher de manière très explicite le contenu et les propriétés d'une variable
    var_dump($prenom);
    
    echo '<hr>';
    
    // Je recommande de l'afficher dans des balises <pre> > pré-formatté
    // var_dump($prix);
?>
<pre><?= var_dump($prix) ?></pre>














    </div>
    
    <!-- Code en couleur -->
    <!-- @see / https://github.com/googlearchive/code-prettify -->
    <!-- Utiliser <pre class="prettyprint">le code</pre> -->
    <script src="https://cdn.jsdelivr.net/gh/google/code-prettify@master/loader/run_prettify.js?&amp;skin=sunburst"></script>
    
    <!-- Notre javascript -->
    <script src="./assets/js/main.js"></script>

</body>

</html>

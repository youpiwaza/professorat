<?php
    // https://stackify.com/display-php-errors/
    ini_set('display_errors', 1);
    ini_set('display_startup_errors', 1);
    error_reporting(E_ALL);
?>

<!doctype html>
<html>

    <head>
        <meta charset="utf-8">
        <title>Un fichier PHP tout simple !</title>

        <!-- Chargement de la police afin de ne plus être dans les années 90 -->
        <!--    Google web fonts > Bebas Neue > https://fonts.google.com/specimen/Bebas+Neue?query=bebas -->
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&display=swap" rel="stylesheet">

        <!-- Favicon -->
        <link rel="shortcut icon"     href="./assets/images/glorious-favicon.ico">
        <link rel="apple-touch-icon"  href="./assets/images/apple-touch-glorious-icon.png">

        <!-- Styles -->
        <link rel="stylesheet" href="./assets/css/normalize.css">
        <link rel="stylesheet" href="./assets/css/main.css">
    </head>

<body>
    <div>

        <h1>Un fichier PHP tout simple</h1>

<?php 
// * Erreurs de mise en place
// 1. On s'assure que XAMPP control panel & Apache soient lancés
// 2. Le fichier est bien dans le dossier xamp
//      C:\xampp\htdocs
//      Max > Applications > XAMPP > htdocs
// 3. Attention à l'extension de fichier.php

// 4. Attention à l'addresse dans le navigateur
//      4.1 Si plusieurs fichiers PHP > ex: http://localhost/03-principales-erreurs/01-mon-exo.php
// !    4.2 Attention à bien ouvrir le php depuis localhost !

echo 'Hello world';
?>

<hr>

<?php

// * Erreurs de syntaxe en PHP
// 1. Attention de bien mettre des ; à chaque fin de "phrase"
    // echo 'Hello world'
// Parse error: syntax error, unexpected token "echo", expecting "," or ";"
//      in C:\xampp\htdocs\03-principales-erreurs\index.php on line 49
// * ^ "Je ne m'attend pas à trouver un 2eme echo la tout de suite, il faut un séparateur
    // echo 'Hello world'

// Utiliser des [ ] ainsi que des { }, des ( )
//      Pensez à refermer !
// $prix = array(10, 20, 30;
// Parse error: syntax error, unexpected token ";", expecting ")" in C:\xampp\htdocs\03-principales-erreurs\index.php on line 55

// Il manque un }
// $age = 19;
// if($age > 18) {
//     echo 'Je suis majeur yay';
    // Parse error: Unclosed '{' on line 59 in C:\xampp\htdocs\03-principales-erreurs\index.php
    //  ! on line 77

// ! Oublie de l'affectation
//      v il manque le caractère '='
// $prenom 'Maxime';
//               v ; à l'intérieur de la chaîne de caractères, donc pas du PHP
// $prenom = 'Maxime;'
?>

    </div>
    
    <!-- Code en couleur -->
    <!-- @see / https://github.com/googlearchive/code-prettify -->
    <!-- Utiliser <pre class="prettyprint">le code</pre> -->
    <script src="https://cdn.jsdelivr.net/gh/google/code-prettify@master/loader/run_prettify.js?&amp;skin=sunburst"></script>
    
    <!-- Notre javascript -->
    <script src="./assets/js/main.js"></script>

</body>

</html>

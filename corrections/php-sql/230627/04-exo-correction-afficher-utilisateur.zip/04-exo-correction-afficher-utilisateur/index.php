<!doctype html>
<html>

    <head>
        <meta charset="utf-8">
        <title>Exo : Afficher un utilisateur !</title>

        <!-- Chargement de la police afin de ne plus être dans les années 90 -->
        <!--    Google web fonts > Bebas Neue > https://fonts.google.com/specimen/Bebas+Neue?query=bebas -->
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&display=swap" rel="stylesheet">

        <!-- Favicon -->
        <link rel="shortcut icon"     href="./assets/images/glorious-favicon.ico">
        <link rel="apple-touch-icon"  href="./assets/images/apple-touch-glorious-icon.png">

        <!-- Styles -->
        <link rel="stylesheet" href="./assets/css/normalize.css">
        <link rel="stylesheet" href="./assets/css/main.css">
    </head>

<body>
    <div>

        <h1>Exo : Afficher un utilisateur</h1>

<?php
    // * Je définis mes variables
    // Prénom
    $prenom     = "Maxime";

    // Nom
    $nom        = "Chevasson";

    // age (type Number)
    $age        = 30;

    // Genre
    $genre      = "Masculin";

    // Adresse
    $adresse    = "7 rue du paf";

    // Code postal
    // ! // nono $cp
    $codePostal = "12345";

    // Veut recevoir la newsletter ? (type Boolean)
    $newsletter = true;

    // Repas préférés (type Array)
    //      indexs            0         1            2
    $repasPreferes = array('pizza', 'burgers', 'une tite salade');

    // Affichage possible mayyyyyyyyyy
    // echo '<p>Mon prénom : ' . $prenom . '</p>';
    // echo "<p>Mon prénom : $prenom</p>";
?>

    <!-- <p>Mon prénom : <?php echo $prenom; ?></p> -->
    
    <p>Mon prénom :             <?= $prenom     ?></p>
    <p>Mon nom :                <?= $nom        ?></p>
    <p>Mon age :                <?= $age        ?></p>
    <p>Mon genre :              <?= $genre      ?></p>
    <p>Mon adresse :            <?= $adresse    ?></p>
    <p>Mon code postal :        <?= $codePostal ?></p>
    <p>Recoit la newsletter ?   <?= $newsletter ?></p>
    <p>Repas préférés :         <?= $repasPreferes[0] ?>, <?= $repasPreferes[1] ?>, <?= $repasPreferes[2] ?></p>

    </div>
    
    <!-- Code en couleur -->
    <!-- @see / https://github.com/googlearchive/code-prettify -->
    <!-- Utiliser <pre class="prettyprint">le code</pre> -->
    <script src="https://cdn.jsdelivr.net/gh/google/code-prettify@master/loader/run_prettify.js?&amp;skin=sunburst"></script>
    
    <!-- Notre javascript -->
    <script src="./assets/js/main.js"></script>

</body>

</html>

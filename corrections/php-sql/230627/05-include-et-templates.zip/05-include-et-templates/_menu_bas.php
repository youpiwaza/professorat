<div class="footer reset-flex">
    <p>Copyright 2023</p>
    <ul>
        <li><a href="#">Mentions légales</a></li>
        <li><a href="#">RGPD</a></li>
        <li><a href="#">Plan du site</a></li>
    </ul>
</div>
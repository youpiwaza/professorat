<div class="header reset-flex">
    <p>Mon super logo</p>
    <!-- Menu -->
    <ul>
        <li><a href="index.php">Accueil</a></li>
        <li><a href="a-propos.php">A propos</a></li>
        <li><a href="contact.php">Contact</a></li>
        <li><a href="#">Ecommerce</a></li>
    </ul>
</div>

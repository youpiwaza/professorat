<?php
    // * Je rajoute l'en-tête du site
    include '_header_html.php';
    include '_menu_haut.php';
?>

<div class="content">
    <h1>A propos</h1>
    <p>Yay c'est la page ou on a les infos</p>
</div>

<?php
    // * Je rajoute l'en-tête du site
    include '_menu_bas.php';
    include '_footer_html.php';
?>

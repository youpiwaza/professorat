<?php
    // * Je rajoute l'en-tête du site
    include '_header_html.php';
    include '_menu_haut.php';
?>

<div class="content">
    <h1>C'est le contenu principal</h1>
    <p>Yay c'est la page d'accueil</p>
</div>

<?php
    // * Je rajoute l'en-tête du site
    include '_menu_bas.php';
    include '_footer_html.php';
?>

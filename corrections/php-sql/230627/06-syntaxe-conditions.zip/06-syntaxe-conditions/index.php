<!doctype html>
<html>

    <head>
        <meta charset="utf-8">
        <title>Les conditions en PHP / La syntaxe !</title>

        <!-- Chargement de la police afin de ne plus être dans les années 90 -->
        <!--    Google web fonts > Bebas Neue > https://fonts.google.com/specimen/Bebas+Neue?query=bebas -->
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&display=swap" rel="stylesheet">

        <!-- Favicon -->
        <link rel="shortcut icon"     href="./assets/images/glorious-favicon.ico">
        <link rel="apple-touch-icon"  href="./assets/images/apple-touch-glorious-icon.png">

        <!-- Styles -->
        <link rel="stylesheet" href="./assets/css/normalize.css">
        <link rel="stylesheet" href="./assets/css/main.css">
    </head>

<body>
    <div>

        <h1>Les conditions en PHP / La syntaxe</h1>

<?php
    // Les conditions > Si ... sinon si .... sinon
    $age = 22;

    // Si age est supérieur à 18
    //      La condition est entre parenthèses
    if( $age >= 18 ) {
        // Si la condition est vraie,
        // le code entre accolades est exécuté

        echo 'Je suis majeur';
    }
    // Sinon
    else {
        // la condition est fausse,
        // le code entre ces accolades la est exécuté
        echo 'Je suis mineur :(';
    }

?>

    </div>
    
    <!-- Code en couleur -->
    <!-- @see / https://github.com/googlearchive/code-prettify -->
    <!-- Utiliser <pre class="prettyprint">le code</pre> -->
    <script src="https://cdn.jsdelivr.net/gh/google/code-prettify@master/loader/run_prettify.js?&amp;skin=sunburst"></script>
    
    <!-- Notre javascript -->
    <script src="./assets/js/main.js"></script>

</body>

</html>

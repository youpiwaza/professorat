<!doctype html>
<html>

    <head>
        <meta charset="utf-8">
        <title>Les boucles en PHP / La syntaxe !</title>

        <!-- Chargement de la police afin de ne plus être dans les années 90 -->
        <!--    Google web fonts > Bebas Neue > https://fonts.google.com/specimen/Bebas+Neue?query=bebas -->
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&display=swap" rel="stylesheet">

        <!-- Favicon -->
        <link rel="shortcut icon"     href="./assets/images/glorious-favicon.ico">
        <link rel="apple-touch-icon"  href="./assets/images/apple-touch-glorious-icon.png">

        <!-- Styles -->
        <link rel="stylesheet" href="./assets/css/normalize.css">
        <link rel="stylesheet" href="./assets/css/main.css">
    </head>

<body>
    <div>

        <h1>Les boucles en PHP / La syntaxe</h1>

<?php
    // * Une boucle toute simple
    // Pour
    //      initialisation, condition de sortie, pas

    // Pour mon compteur qui va de 0 jusqu'à 5, je l'augmente de 1 à chaque tour
    //      Et j'en profite pour faire quelque chose

    // $compteur = 0;   // Je commence à 0
    // $compteur < 5;   // Je continue tant que compteur est plus petit que 5
    // $compteur++      // A chaque tour je rajoute 1

    for( $compteur = 0 ; $compteur < 5 ; $compteur++) {
        // A l'intérieur de ces accolades
        // Le code sera exécuté à chaque tour de boucle
        echo "<p>bonjour ! j'en suis au tour " . $compteur . " </p>";
    }

    // Afficher un séparateur entre les deux boucles
    echo '<hr>';

    // * Un parcours de tableau
    //          Afficher chacun des éléments du tableau
    //                       0          1       2           3       4
    $repasPreferes = array('pizza', 'burger', 'salade', 'nems', 'tomates');

    // On récupérer le nombre d'éléments dans le tableau
    $nombreDeRepas = count($repasPreferes);

    for( $compteur = 0 ; $compteur < $nombreDeRepas ; $compteur++) {
        // A l'intérieur de ces accolades
        // Le code sera exécuté à chaque tour de boucle
        echo "<p>Voici mes repas préférés: " . $repasPreferes[$compteur] . " </p>";
    }
?>


    </div>
    
    <!-- Code en couleur -->
    <!-- @see / https://github.com/googlearchive/code-prettify -->
    <!-- Utiliser <pre class="prettyprint">le code</pre> -->
    <script src="https://cdn.jsdelivr.net/gh/google/code-prettify@master/loader/run_prettify.js?&amp;skin=sunburst"></script>
    
    <!-- Notre javascript -->
    <script src="./assets/js/main.js"></script>

</body>

</html>

<!doctype html>
<html>

    <head>
        <meta charset="utf-8">
        <title>Correction projet blog !</title>

        <!-- Chargement de la police afin de ne plus être dans les années 90 -->
        <!--    Google web fonts > Bebas Neue > https://fonts.google.com/specimen/Bebas+Neue?query=bebas -->
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&display=swap" rel="stylesheet">

        <!-- Favicon -->
        <link rel="shortcut icon"     href="./assets/images/glorious-favicon.ico">
        <link rel="apple-touch-icon"  href="./assets/images/apple-touch-glorious-icon.png">

        <!-- Styles -->
        <link rel="stylesheet" href="./assets/css/normalize.css">
        <link rel="stylesheet" href="./assets/css/main.css">
    </head>

<body>


    <div>

        <div class="header">
            <img src="./assets/images/Masamune-le-blog-logo.png" alt="">
            <ul>
                <li>
                    <a href="#">Accueil</a>
                    <a href="#">A propos</a>
                    <a href="#">Contact</a>
                </li>
            </ul>
        </div>

        <div class="content">
            <h1>Correction projet blog</h1>
            <p>Wesh mon super blog ou on donne des conseils sur la vie</p>

            <section>
                <!-- Une sauvegarde de mes articles affichés correctement -->
                <!-- 
                <article>
                    <h2>Le titre</h2>
                    <p class="date">27/06/2023</p>
                    <div class="texte">Lorem ipsum dolor sit amet consectetur adipisicing elit.
                        Repudiandae officiis odio consequuntur sint tenetur
                        distinctio sapiente natus, neque asperiores ex!</div>
                    <p class="auteur">Beh c'est moi</p>
                </article>
                -->

            <?php
// * Récupération de l'exemple de base de PHP
// @see     https://www.php.net/manual/fr/pdo.connections.php

// On rend la variable accessible à l'extérieur du try...catch (portée des variables / scope)
try {
    // ! Connexion
    // * On ajuste nos informations
    $hote                = 'localhost';
    $nom_base_de_donnees = 'une_nouvelle_base_de_donnees_tavu_wesh';
    // Les défauts phpmyadmin
    $utilisateur         = 'root';
    $mot_de_passe        = '';

    $dbh = new PDO(
                'mysql:host=' . $hote . ';dbname=' . $nom_base_de_donnees
                , $utilisateur
                , $mot_de_passe
    );

    // Gestion propre des caractères accentués (encodage)
    $dbh->exec("SET NAMES 'utf8';");

    // ! Requête de récupération
    // @see     https://www.php.net/manual/fr/pdo.prepared-statements.php

    // Je prépare ma requête SQL
    $mes_articles = $dbh->prepare("SELECT * FROM `articles`");
    
    // Je l'execute dans la base de donnée, si c'est possible est renvoie les résultats
    $mes_articles->execute();

    // * Si il y a plusieurs résultats, ils sont retounés sous forme de tableau
    // * Je peux le parcourir afin de faire l'affichage
    
    // Pour chacun des articles
    // Affichage avec de belles balises html
    foreach ($mes_articles as $un_article) {

        // ! Je gère l'affichage html de mes articles ici
?>

        <article>

            <h2>
                <?= $un_article['titre'] ?>
            </h2>
            
            <p class="date"><?= $un_article['date_publication'] ?></p>
            
            <div class="texte"><?= $un_article['contenu'] ?></div>
            
            <p class="categories"><?= $un_article['categories'] ?></p>
            
            <p class="likes">
                Nombre de likes :
                <?= $un_article['mes_like'] ?>
            </p>
            
            <p class="auteur">Beh c'est moi</p>
        </article>

<?php
        }
}
// ! Au cas ou on choppe les erreurs (mauvaise connexion, mauvaise base ou requête)
catch (PDOException $e) {
    // Note, $e contient beaucoup d'informations, n'hésitez pas a var_dump en cas de problème
    print "Erreur !: " . $e->getMessage() . "<br/>";
    die();
}
?>


                

            </section>

        </div>

        <div class="footer">
            © Copyright Masamune 2023
        </div>

    </div>
    
    <!-- Code en couleur -->
    <!-- @see / https://github.com/googlearchive/code-prettify -->
    <!-- Utiliser <pre class="prettyprint">le code</pre> -->
    <script src="https://cdn.jsdelivr.net/gh/google/code-prettify@master/loader/run_prettify.js?&amp;skin=sunburst"></script>
    
    <!-- Notre javascript -->
    <script src="./assets/js/main.js"></script>

</body>

</html>

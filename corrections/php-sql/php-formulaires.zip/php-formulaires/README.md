# PHP / Formulaires

## Besoin de deux pages

Une avec formulaire

Une avec gestion de ce que le formulaire a envoyé

## Création d'un formulaire

Structure html

- form
  - attributs
    - method
    - action
- input
  - attributs
    - name
    - type
      - text
      - submit
    - id (pour le label)
- label
  - attributs
    - for

Comportement & passage des données

## Page de récupération des données

### Super globales

`$_GET` & `$_POST`

# HTML5Boilerplate / light

Basé sur cette [référence](https://html5boilerplate.com/).

En ayant retiré tous les petits fichiers ~parasites pour débuter la programmation :)

Il contient un peu de HTML, CSS, Javascript, déjà liés, avec un peu de couleur & polices.

Il servira de base pour créer des "packs débutants" pour les différents langages.

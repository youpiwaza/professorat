console.log('Coucou depuis le fichier "/assets/js/main.js"');

# HTML5Boilerplate / light

Ce fichier contient la documentation de ce projet, au format [markdown](https://www.markdownguide.org/basic-syntax/).

## Récupération du projet

Récupérez ce projet en cliquant sur ce lien : [https://github.com/youpiwaza/evogue/archive/refs/heads/main.zip](https://github.com/youpiwaza/evogue/archive/refs/heads/main.zip)

Décompressez l'archive, puis il se trouvera dans le dossier `/ressources/packs-debutants/`**TODO**`-debutant/`.

## Mise en place

hey **TODO**

---

Basé sur cette [référence](https://html5boilerplate.com/).

En ayant retiré tous les petits fichiers ~parasites pour débuter la programmation :)

Il contient un peu de HTML, CSS, Javascript, déjà liés, avec un peu de couleur & polices.

Il servira de base pour créer des "packs débutants" pour les différents langages.
